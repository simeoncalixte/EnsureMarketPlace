# Ensured Call Graph

Generate animated 3D call graphs from JavaScript / TypeScript directories or supplied JSON. The default HTML is a byte-for-byte copy of the supplied Schema-on-Read Observatory reference. Custom graphs reuse its CSS, typography, glass HUD, cyan/violet palette, Three.js version and bloom; their graph layout and camera are adapted to arbitrary source data.

```sh
# From the repository root (existing root TypeScript installation works):
node EnsuredCallGraph/src/cli.js ./EnsuredAPI/src --output outputs/call-graph/index.html
# Exact reference demo:
node EnsuredCallGraph/src/cli.js --output outputs/call-graph/reference.html
# Package checks:
npm --prefix EnsuredCallGraph test
```

Open the generated HTML in a browser. It loads pinned Three.js scripts from public CDNs and fonts from Google Fonts, so internet access and WebGL are required. Select node labels to inspect calls; use **Take control · C** to switch from auto-follow to manual camera movement. WASD moves, R/F moves up/down, arrow keys pitch/yaw, Q/E rolls, and Shift moves faster. Press C or **Resume follow** to return to auto-follow. Space or Pause freezes the animation while manual camera movement remains available. Traffic is illustrative animation, not measured runtime execution.

```js
import { analyzeCallGraph, createCallGraph } from '@ensured/call-graph';
import { writeFile } from 'node:fs/promises';
const graph = await analyzeCallGraph('./src');
await writeFile('call-graph.html', createCallGraph(graph));
```

JSON accepts `{ title?, nodes: [{ id, label?, description?, color? }], edges: [{ source, target }] }`. IDs must be unique and edge endpoints must exist. Colors use `#RRGGBB`. Call-site file and line metadata from analysis remain in the graph data.

Analysis is syntactic: it collects functions, methods, arrow functions, module-level calls, calls and constructors. It resolves simple file-level function identifiers and relative named imports. Member dispatch, default/namespace imports, aliases, nested scopes, overload dispatch, runtime bindings, and TypeScript path mappings are not fully resolved. Unknown targets appear as `UNRESOLVED`; this is not a complete compiler or runtime call graph. Dependency, build and Git directories are skipped. Very large graphs work best when analyzing a smaller source directory.

The package has no build step. For independent installation run `npm install` inside this directory; use `npm pack` to create an installable tarball. The original design reference lives in `templates/index.html` and is preserved independently of the custom renderer.

Each source file has its own labeled ring. Nodes have a minimum 12-unit separation around each ring, and file rings have a 32-unit gutter. Unresolved targets use a separate ring. **All files** fits the complete scene and enables manual camera control. Only calls connected to the focused function animate, including cross-file calls, to avoid a wall of overlapping traffic. Bloom is reduced for readable node boundaries. JSON nodes may supply `file` to specify their ring.

## Exclusions

The CLI reads `callgraph.config.json` in the analyzed directory, falling back to the current working directory. Use `--config path/to/config.json` to select a specific config. Patterns are relative to the analyzed directory and support `*`, `**`, and `?`. Custom exclusions add to the built-in exclusions for tests, mocks, fixtures, declarations, dependencies, build output, coverage, and Git files.

```json
{
  "exclude": ["scripts/**", "src/generated/**", "src/legacy.ts"],
  "includeExternalPackages": false,
  "includeUnresolvedCalls": false
}
```

External package import bindings (including Node built-ins) and their calls are excluded by default. Unresolved calls are also hidden by default, which can omit internal calls that the syntactic analyzer cannot resolve. Set `includeUnresolvedCalls` to true to inspect those targets; imported external-package calls stay hidden unless `includeExternalPackages` is enabled. Calls to excluded relative imports stay hidden. CommonJS `require` bindings and TypeScript path aliases are not classified as package imports; their calls fall under unresolved filtering.

The API accepts the same options as its second argument: `analyzeCallGraph('./src', { exclude: ['generated/**'] })`. API callers supply options directly; only the CLI discovers config files. Existing generated HTML must be regenerated to apply config changes.

## Solar systems

Sections under `src` are grouped as solar systems: all files beneath `src/routes`, including nested directories, belong to the `src/routes` system; `src/pipeline` forms another system. Files directly under `src` belong to a shared `src` system. Other directories group by their first path component; external targets have their own system. A section hub is the sun, files are planets with their own rings, and functions orbit their file. Additional file orbits are added for large sections, with clearance between file rings and section systems. Use **Go to section…** to frame a system, **All systems** for the overall view, and C to switch between manual camera movement and auto-follow.
