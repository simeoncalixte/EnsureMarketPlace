import {readFile} from 'node:fs/promises';
import path from 'node:path';
export const defaultConfig = {
  exclude: ['**/node_modules/**','**/.git/**','**/dist/**','**/build/**','**/coverage/**','**/test/**','**/tests/**','**/__tests__/**','**/__mocks__/**','**/fixtures/**','**/*.test.*','**/*.spec.*','**/*.d.ts'],
  includeExternalPackages: false,
  includeUnresolvedCalls: false,
};
export function normalizeConfig(config={}) {
  if(!config||typeof config!=='object'||Array.isArray(config))throw new TypeError('Call graph config must be an object');
  for(const key of Object.keys(config))if(!Object.hasOwn(defaultConfig,key))throw new TypeError(`Unknown call graph config option: ${key}`);
  if(config.exclude!==undefined&&(!Array.isArray(config.exclude)||config.exclude.some(p=>typeof p!=='string')))throw new TypeError('exclude must be an array of glob strings');
  for(const key of ['includeExternalPackages','includeUnresolvedCalls'])if(config[key]!==undefined&&typeof config[key]!=='boolean')throw new TypeError(`${key} must be boolean`);
  return {...defaultConfig,...config,exclude:[...defaultConfig.exclude,...(config.exclude||[])]};
}
/** Supported globs: *, ** and ?. Paths are relative to the analyzed directory. */
export function excluded(file,patterns) {
  return patterns.some(pattern=>{
    let expression='';const glob=pattern.replaceAll('\\','/').replace(/^\.\//,'');
    for(let i=0;i<glob.length;i++){
      if(glob[i]==='*'&&glob[i+1]==='*'){i++;if(glob[i+1]==='/'){i++;expression+='(?:.*/)?';}else expression+='.*';}
      else if(glob[i]==='*')expression+='[^/]*';else if(glob[i]==='?')expression+='[^/]';
      else expression+=glob[i].replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
    }
    return new RegExp('^'+expression+'$').test(file);
  });
}
export async function loadConfig(directory,explicitPath) {
  const candidates=explicitPath?[path.resolve(explicitPath)]:[path.resolve(directory,'callgraph.config.json'),path.resolve('callgraph.config.json')];
  for(const file of [...new Set(candidates)]){try{return normalizeConfig(JSON.parse(await readFile(file,'utf8')));}catch(error){if(error.code==='ENOENT'&&!explicitPath)continue;throw error;}}
  return normalizeConfig();
}
