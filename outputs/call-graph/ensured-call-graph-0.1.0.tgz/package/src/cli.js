#!/usr/bin/env node
import { readFile, mkdir, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { stat } from 'node:fs/promises';
import {loadConfig} from './config.js';
import { analyzeCallGraph } from './analyze.js';
import { createCallGraph } from './index.js';
try {
  const args = process.argv.slice(2);
  if (args.includes('--help')) {
    console.log('Usage: ensured-call-graph [source-directory|graph.json] [--output output/index.html] [--config callgraph.config.json]\nOmit graph.json for the original reference observatory.');
  } else {
    let input, configPath, output = 'output/index.html';
    for (let i = 0; i < args.length; i++) {
      if (args[i] === '--output' && args[i + 1]) output = args[++i];
      else if (args[i] === '--config' && args[i + 1]) configPath = args[++i];
      else if (!args[i].startsWith('-') && !input) input = args[i];
      else throw new Error(`Unknown or incomplete argument: ${args[i]}`);
    }
    const graph = input ? ((await stat(input)).isDirectory() ? await analyzeCallGraph(input, await loadConfig(input,configPath)) : JSON.parse(await readFile(input, 'utf8'))) : undefined;
    const html = createCallGraph(graph);
    await mkdir(dirname(resolve(output)), { recursive: true });
    await writeFile(output, html);
    console.log(resolve(output));
  }
} catch (error) { console.error(error.message); process.exitCode = 1; }
