(()=>{
const graph=window.CALL_GRAPH, $=id=>document.getElementById(id);
const text=(id,value)=>{const el=$(id);if(el)el.textContent=value;};
document.title=graph.title||'Call Graph Observatory';
document.querySelector('.brand h1').textContent='CALL · GRAPH';
document.querySelector('.brand p').textContent='JAVASCRIPT / TYPESCRIPT · STATIC ANALYSIS';
document.querySelector('.status').replaceChildren($('designSystemOpen')); const status=document.createElement('span');status.textContent='STATIC ANALYSIS';document.querySelector('.status').prepend(status);
text('workflowName','CALL GRAPH');text('workflowDetail','Select a node to inspect its incoming and outgoing calls.');text('workflowStep',graph.nodes.length+' NODES');
text('cameraRoute','Auto orbit');text('workflowStatus','Static graph · animated calls');text('submissionLabel','SOURCE ANALYSIS');text('submissionOrigin','JavaScript / TypeScript');text('ingressStatus','Unresolved calls are shown explicitly');text('ingressQueue','—');
text('kDocs',graph.nodes.length);text('kDocsS','functions / external targets');text('kLat','—');text('kLatS','static analysis');text('kMat',graph.edges.length);text('kMatS','call sites');
document.querySelectorAll('.kpi small').forEach((el,i)=>el.textContent=['NODES','RUNTIME','CALLS','MIGRATIONS'][i]);

text('capn','CALL GRAPH / OBSERVATORY');text('capx',graph.title||'Source call graph');
text('payload',JSON.stringify({nodes:graph.nodes.length,calls:graph.edges.length},null,2));text('sql','Select a function to inspect its calls.');
const table=$('reg');table.replaceChildren();graph.nodes.forEach(n=>{const tr=document.createElement('tr');tr.className='on';const a=document.createElement('td'),b=document.createElement('td');a.textContent=n.label||n.id;b.textContent=n.external?'UNRESOLVED':'FUNCTION';tr.append(a,b);table.append(tr);});
document.querySelector('.schema-panel .ph b').textContent='FUNCTION REGISTRY';text('regtag','STATIC');

const panels=document.querySelectorAll('.col.l .panel');panels[0].style.minHeight='340px';panels[1].style.minHeight='150px';panels.forEach(panel=>panel.querySelectorAll('pre').forEach(pre=>{pre.style.overflow='auto';pre.style.maxHeight='160px';}));
panels[0].querySelectorAll('.ph')[1].textContent='FUNCTION METADATA';panels[1].querySelector('.ph').textContent='CALL SITES · SOURCE → TARGET';
document.querySelector('.schema-panel .ph').firstElementChild.textContent='FUNCTION REGISTRY · source symbols';
text('kLat',graph.nodes.filter(n=>n.external).length);text('kLatS','unresolved targets');text('kDocsS','source symbols + targets');
document.querySelectorAll('.kpi small')[1].textContent='UNRESOLVED';document.querySelectorAll('.kpi small')[3].textContent='RESOLVED';document.querySelectorAll('.kpi strong')[3].textContent=graph.edges.filter(e=>!e.target.startsWith('unresolved:')).length;document.querySelectorAll('.kpi span')[3].textContent='static call sites';
document.querySelector('.col.r .panel .ph').textContent='CALL DISTRIBUTION · STATIC';
const spark=$('spark').getContext('2d');spark.strokeStyle='#39e6ff';spark.shadowBlur=10;spark.shadowColor='#39e6ff';spark.beginPath();for(let i=0;i<40;i++){const n=graph.nodes[i%graph.nodes.length];const count=graph.edges.filter(e=>e.source===n.id).length;spark.lineTo(i*7.5,50-Math.min(44,count*5));}spark.stroke();
const donut=$('donut').getContext('2d');let from=-Math.PI/2;const groups=[graph.nodes.filter(n=>!n.external).length,graph.nodes.filter(n=>n.external).length];groups.forEach((count,i)=>{donut.beginPath();donut.strokeStyle=['#39e6ff','#b46bff'][i];donut.lineWidth=9;const to=from+count/graph.nodes.length*Math.PI*2;donut.arc(42,42,32,from,to);donut.stroke();from=to;});
document.querySelectorAll('.col.r .panel')[1].querySelector('.ph').textContent='TARGET RESOLUTION';document.querySelector('.legend').replaceChildren();groups.forEach((count,i)=>{const row=document.createElement('div');row.textContent=(i?'Unresolved':'Source symbols')+' · '+count;document.querySelector('.legend').append(row);});
document.querySelectorAll('.pc').forEach((el,i)=>el.classList.toggle('on',i===0));document.querySelector('.pc .ph').textContent='SELECTED FUNCTION';text('docpre','Awaiting node focus');document.querySelector('.pc .row').textContent='Static analysis · source locations retained';
const timeline=document.querySelector('.tl');timeline.replaceChildren();graph.nodes.slice(0,14).forEach((n,i)=>{const seg=document.createElement('div');seg.className='seg';const lab=document.createElement('div');lab.className='lab';lab.textContent=String(i+1).padStart(2,'0')+' '+(n.label||n.id).slice(0,24);const track=document.createElement('div');track.className='track';track.append(document.createElement('i'));seg.append(lab,track);timeline.append(seg);});document.querySelector('.foot2').textContent='SOURCE → CALL → TARGET · STATIC ANALYSIS · ANIMATED HANDOFFS';

const renderer=new THREE.WebGLRenderer({canvas:$('gl'),antialias:true});renderer.setPixelRatio(Math.min(devicePixelRatio,2));
const scene=new THREE.Scene();scene.background=new THREE.Color(0x03050c);scene.fog=new THREE.FogExp2(0x03050c,.007);
const camera=new THREE.PerspectiveCamera(40,innerWidth/innerHeight,.1,1000);
const composer=new THREE.EffectComposer(renderer);composer.addPass(new THREE.RenderPass(scene,camera));composer.addPass(new THREE.UnrealBloomPass(new THREE.Vector2(innerWidth,innerHeight),.35,.35,.5));
scene.add(new THREE.AmbientLight(0x2a3a66,.5));
const TAU=Math.PI*2;const rnd=Math.random;
/* glow texture */
const glowTex=(()=>{const c=document.createElement('canvas');c.width=c.height=128;const g=c.getContext('2d');
  const gr=g.createRadialGradient(64,64,0,64,64,64);gr.addColorStop(0,'rgba(255,255,255,1)');gr.addColorStop(.18,'rgba(255,255,255,.65)');
  gr.addColorStop(.45,'rgba(255,255,255,.14)');gr.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=gr;g.fillRect(0,0,128,128);
  return new THREE.CanvasTexture(c);})();
const mkGlow=(color,s,op=1)=>{const sp=new THREE.Sprite(new THREE.SpriteMaterial({map:glowTex,color,transparent:true,opacity:op,
  blending:THREE.AdditiveBlending,depthWrite:false}));sp.scale.setScalar(s);return sp;};

/* ---------- floor (shader grid with pulse ring) ---------- */
const floorMat=new THREE.ShaderMaterial({
  extensions:{derivatives:true},
  uniforms:{uRing:{value:-10},uRingA:{value:0},uRingC:{value:new THREE.Color(0x39e6ff)},uT:{value:0}},
  vertexShader:`varying vec3 vW;void main(){vec4 w=modelMatrix*vec4(position,1.);vW=w.xyz;gl_Position=projectionMatrix*viewMatrix*w;}`,
  fragmentShader:`varying vec3 vW;uniform float uRing,uRingA,uT;uniform vec3 uRingC;
    float grid(vec2 p,float s){vec2 q=p/s;vec2 g=abs(fract(q-.5)-.5)/fwidth(q);return 1.-min(min(g.x,g.y),1.);}
    void main(){vec2 p=vW.xz;float d=length(p);
      float l1=grid(p,1.15),l2=grid(p,5.75);
      float fade=exp(-d*.05);
      float ring=exp(-pow((d-uRing)*.8,2.))*uRingA;
      float scanl=.5+.5*sin(d*.9-uT*6.2831/15.*8.);
      vec3 c=vec3(.03,.06,.12)*fade+vec3(.10,.32,.55)*l1*.35*fade+vec3(.2,.6,1.)*l2*.45*fade*(.7+.3*scanl);
      c+=uRingC*ring*(.25+l1*1.6)*fade*1.5;
      gl_FragColor=vec4(c+vec3(.012,.02,.047)*(1.-fade),1.);}`
});
const floor=new THREE.Mesh(new THREE.PlaneGeometry(260,260),floorMat);
floor.rotation.x=-Math.PI/2; floor.position.y=-2.6; scene.add(floor);

/* ---------- stars ---------- */
{const n=1800,pos=new Float32Array(n*3);for(let i=0;i<n;i++){const r=70+rnd()*120,a=rnd()*TAU,b=Math.acos(rnd()*1.6-.6);
  pos[i*3]=Math.sin(b)*Math.cos(a)*r;pos[i*3+1]=Math.cos(b)*r;pos[i*3+2]=Math.sin(b)*Math.sin(a)*r;}
 const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(pos,3));
 var stars=new THREE.Points(g,new THREE.PointsMaterial({color:0x7fa8ff,size:.5,transparent:true,opacity:.7,fog:false}));scene.add(stars);}

const palette=['#39e6ff','#b46bff','#ffb547','#34ffc8'];const map=new Map(),objects=[];
const layout=layoutCallGraph(graph);
const moduleLabels=[];
layout.systems.forEach((system,i)=>{
 const color=palette[i%palette.length];
 const sun=new THREE.Mesh(new THREE.SphereGeometry(2,20,16),new THREE.MeshBasicMaterial({color}));sun.position.set(system.x,2,system.z);sun.add(mkGlow(color,8,.2));scene.add(sun);
 system.orbits.forEach(radius=>{const points=Array.from({length:193},(_,j)=>{const a=j/192*Math.PI*2;return new THREE.Vector3(system.x+Math.cos(a)*radius,-1,system.z+Math.sin(a)*radius);});scene.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(points),new THREE.LineBasicMaterial({color,transparent:true,opacity:.12})));});
 const label=document.createElement('div');label.className='lbl node-card';label.style.color=color;const title=document.createElement('div');title.className='t';const name=document.createElement('b');name.textContent=system.name.toUpperCase();const count=document.createElement('span');count.textContent=system.fileCount+' files · solar system';title.append(name,count);label.append(title);$('labels').append(label);moduleLabels.push({label,p:new THREE.Vector3(system.x,6,system.z)});
});
layout.rings.forEach((ring,i)=>{const color=palette[layout.systems.findIndex(s=>s.name===ring.section)%palette.length];const planet=new THREE.Mesh(new THREE.SphereGeometry(.9,12,10),new THREE.MeshBasicMaterial({color}));planet.position.set(ring.x,1,ring.z);scene.add(planet);const points=Array.from({length:129},(_,j)=>{const a=j/128*Math.PI*2;return new THREE.Vector3(ring.x+Math.cos(a)*ring.radius,0,ring.z+Math.sin(a)*ring.radius);});scene.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(points),new THREE.LineBasicMaterial({color,transparent:true,opacity:.35})));const label=document.createElement("div");label.className="lbl chip";label.style.color=color;const title=document.createElement("div");title.className="t";const name=document.createElement("b");name.textContent=ring.file+" · "+ring.count+" nodes";title.append(name);label.append(title);$("labels").append(label);moduleLabels.push({label,p:new THREE.Vector3(ring.x,1,ring.z)});});
function select(n){text('docpre',JSON.stringify({function:n.label||n.id,location:n.description||'',resolution:n.external?'unresolved':'source'},null,2));text('capx',n.label||n.id);text('workflowDetail',n.description||n.id);text('payload',JSON.stringify(n,null,2));text('sql',graph.edges.filter(e=>e.source===n.id||e.target===n.id).map(e=>e.source+' → '+e.target).join('\n')||'No recorded calls');}
graph.nodes.forEach((n,i)=>{const position=layout.positions[n.id],groupIndex=layout.systems.findIndex(s=>s.name===position.section),color=n.color||palette[groupIndex%4],p=new THREE.Vector3(position.x,position.y,position.z);
const mesh=new THREE.Mesh(new THREE.OctahedronGeometry(1.1),new THREE.MeshBasicMaterial({color,wireframe:true}));mesh.position.copy(p);mesh.userData.node=n;scene.add(mesh);objects.push(mesh);const glow=mkGlow(color,2.5,.12);mesh.add(glow);const core=mkGlow(color,.7,.6);mesh.add(core);const ring=new THREE.Mesh(new THREE.TorusGeometry(1.8,.015,8,64),new THREE.MeshBasicMaterial({color,transparent:true,opacity:.5}));ring.rotation.x=Math.PI/2;mesh.add(ring);
const label=document.createElement('div');label.className='lbl node-card';label.style.color=color;label.style.pointerEvents='auto';const box=document.createElement('button');box.className='t';box.style.cssText='color:inherit;cursor:pointer;text-align:left;font-family:var(--font-code)' ;const title=document.createElement('b');title.textContent=(n.label||n.id).replace(/\s+/g,' ').slice(0,64);title.title=n.label||n.id;const sub=document.createElement('span');sub.textContent=n.external?'unresolved / external':n.description||'function';box.append(title,sub);box.onclick=()=>select(n);label.append(box);$('labels').append(label);map.set(n.id,{p,mesh,label});});
const routes=graph.edges.map(e=>{const a=map.get(e.source).p,b=map.get(e.target).p;const mid=a.clone().add(b).multiplyScalar(.5);mid.y+=e.source===e.target?9:5;const end=b.clone();if(e.source===e.target)end.x+=.8;const curve=new THREE.QuadraticBezierCurve3(a,mid,end);const tube=new THREE.Mesh(new THREE.TubeGeometry(curve,40,.035,5,false),new THREE.MeshBasicMaterial({color:0x39e6ff,transparent:true,opacity:.25}));scene.add(tube);const packet=mkGlow(0xafffff,.8,.5);scene.add(packet);return {curve,packet,tube,source:e.source,target:e.target};});
let paused=false,elapsed=0,last=0,angle=0,activeIndex=-1;
document.querySelectorAll('.camera-controls').forEach(el=>el.remove());
const controls=document.createElement('div');controls.className='camera-controls';controls.setAttribute('aria-label','Camera controls');
const mode=document.createElement('span');mode.id='cameraMode';mode.textContent='Auto follow';
const toggle=document.createElement('button');toggle.id='cameraToggle';toggle.textContent='Take control · C';
const btn=document.createElement('button');btn.textContent='Pause';
function togglePause(){paused=!paused;btn.textContent=paused?'Resume':'Pause';}
btn.onclick=togglePause;
const help=document.createElement('p');help.textContent='WASD move · R/F up/down · ↑/↓ pitch · ←/→ yaw · Q/E roll · Shift faster · Space pause';
const overview=document.createElement('button');overview.textContent='All systems';overview.onclick=()=>{setManualCamera(true);const extent=Math.max(25,...layout.rings.map(r=>Math.max(Math.abs(r.x),Math.abs(r.z))+r.radius));camera.position.set(extent*.25,extent*1.8,extent*2);camera.lookAt(0,0,0);};const systemSelect=document.createElement('select');systemSelect.setAttribute('aria-label','Solar system');systemSelect.style.cssText='background:#10213b;color:var(--ink);border:1px solid var(--line);padding:5px;font:inherit;margin-left:8px';const placeholder=document.createElement('option');placeholder.textContent='Go to section…';placeholder.value='';systemSelect.append(placeholder);layout.systems.forEach((system,i)=>{const option=document.createElement('option');option.value=i;option.textContent=system.name;systemSelect.append(option);});systemSelect.onchange=()=>{if(systemSelect.value==='')return;const system=layout.systems[Number(systemSelect.value)];setManualCamera(true);camera.position.set(system.x,system.radius*1.8,system.z+system.radius*2);camera.lookAt(system.x,0,system.z);};controls.append(mode,toggle,overview,systemSelect,btn,help);document.body.append(controls);
let manualCamera=false;
const cameraKeys=new Set();
const cameraMotionCodes=new Set(['KeyW','KeyA','KeyS','KeyD','KeyR','KeyF','KeyQ','KeyE','ArrowUp','ArrowDown','ArrowLeft','ArrowRight']);
const cameraMovement=new THREE.Vector3();
function setManualCamera(enabled){
  manualCamera=enabled;cameraKeys.clear();
  $('cameraMode').textContent=enabled?'Manual camera':'Auto follow';
  $('cameraToggle').textContent=enabled?'Resume follow · C':'Take control · C';
}
function cameraInputBlocked(event){
  return event.ctrlKey||event.metaKey||event.altKey||document.querySelector('dialog[open]')||event.target.closest('input,textarea,select,[contenteditable="true"]');
}
function updateManualCamera(dt){
  const axis=(positive,negative)=>Number(cameraKeys.has(positive))-Number(cameraKeys.has(negative));
  const turn=1.1*dt;
  camera.rotateY(axis('ArrowLeft','ArrowRight')*turn);
  camera.rotateX(axis('ArrowUp','ArrowDown')*turn);
  camera.rotateZ(axis('KeyQ','KeyE')*turn);
  cameraMovement.set(axis('KeyD','KeyA'),axis('KeyR','KeyF'),axis('KeyS','KeyW'));
  if(cameraMovement.lengthSq()>0){
    const speed=cameraKeys.has('ShiftLeft')||cameraKeys.has('ShiftRight')?30:12;
    cameraMovement.normalize().applyQuaternion(camera.quaternion).multiplyScalar(speed*dt);
    camera.position.add(cameraMovement);
  }
}
$('cameraToggle').addEventListener('click',()=>setManualCamera(!manualCamera));
addEventListener('keyup',event=>cameraKeys.delete(event.code));
addEventListener('blur',()=>cameraKeys.clear());
$('designSystemOpen').addEventListener('click',()=>cameraKeys.clear());
addEventListener('keydown',event=>{
  if(cameraInputBlocked(event))return;
  if(event.code==='KeyC'){event.preventDefault();if(!event.repeat)setManualCamera(!manualCamera);return;}
  if(event.code==='Space'){if(event.target.closest('button'))return;event.preventDefault();if(!event.repeat)togglePause();return;}
  if(cameraMotionCodes.has(event.code)){event.preventDefault();if(!manualCamera)setManualCamera(true);cameraKeys.add(event.code);if(event.shiftKey)cameraKeys.add('ShiftLeft');}
  else if(event.code==='ShiftLeft'||event.code==='ShiftRight')cameraKeys.add(event.code);
});
function resize(){renderer.setSize(innerWidth,innerHeight);composer.setSize(innerWidth,innerHeight);camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();}addEventListener('resize',resize);resize();
function frame(now){requestAnimationFrame(frame);const dt=last?Math.min(.1,(now-last)/1000):0;last=now;if(!paused){elapsed+=dt;angle+=dt*.06;}const focusIndex=Math.floor(elapsed/7)%graph.nodes.length;const focus=map.get(graph.nodes[focusIndex].id).p;const destination=focus.clone().add(new THREE.Vector3(4,15,25));if(manualCamera){updateManualCamera(dt);}else{camera.position.lerp(destination,1-Math.exp(-4*dt));camera.lookAt(focus);}floorMat.uniforms.uT.value=elapsed; if(focusIndex!==activeIndex){activeIndex=focusIndex;select(graph.nodes[focusIndex]);text('workflowStep',String(focusIndex+1).padStart(2,'0')+' / '+graph.nodes.length);document.querySelectorAll('.seg').forEach((el,i)=>el.classList.toggle('on',i===focusIndex%14));}document.querySelectorAll('.track i').forEach((el,i)=>el.style.width=(i<focusIndex%14?100:i===focusIndex%14?(elapsed%7)/7*100:0)+'%');routes.forEach((r,i)=>{const active=r.source===graph.nodes[focusIndex].id||r.target===graph.nodes[focusIndex].id;r.tube.visible=active;r.packet.visible=active;r.packet.position.copy(r.curve.getPoint((elapsed*.25+i*.17)%1));});const occupied=[];map.forEach(({p,mesh,label})=>{mesh.visible=true;mesh.rotation.y=elapsed*.4;const v=p.clone().project(camera);label.style.transform=`translate(${(v.x*.5+.5)*innerWidth}px,${(-v.y*.5+.5)*innerHeight}px)`;const x=(v.x*.5+.5)*innerWidth,y=(-v.y*.5+.5)*innerHeight;const overlaps=occupied.some(([ox,oy])=>Math.abs(x-ox)<205&&Math.abs(y-oy)<64);const visible=(manualCamera||p.distanceTo(focus)<30)&&v.z<1&&Math.abs(v.x)<.8&&Math.abs(v.y)<.8&&(!overlaps||p===focus);if(visible)occupied.push([x,y]);label.style.opacity=visible?'1':'0';label.style.pointerEvents=visible?'auto':'none';label.classList.toggle('expanded',p===focus);});moduleLabels.forEach(({p,label})=>{const v=p.clone().project(camera);label.style.transform=`translate(${(v.x*.5+.5)*innerWidth}px,${(-v.y*.5+.5)*innerHeight}px)`;label.style.opacity=v.z<1?'1':'0';});composer.render();}requestAnimationFrame(frame);
})();
