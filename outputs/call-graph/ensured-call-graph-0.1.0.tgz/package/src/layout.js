/** Sections are solar systems; files orbit the section hub, functions orbit files. */
export function layoutCallGraph(graph) {
  const groups=new Map();
  const sectionFor=file=>{
    if(file==='External / unresolved'||file==='Graph')return file;
    const parts=file.replaceAll('\\','/').split('/');const src=parts.indexOf('src');
    if(src>=0)return parts.length>src+2?parts.slice(0,src+2).join('/') : parts.slice(0,src+1).join('/');
    return parts.length>1?parts[0]:'Root files';
  };
  for(const node of graph.nodes){const file=node.file||(node.external?'External / unresolved':node.id.match(/^(.*?\.[cm]?[jt]sx?)(?=:|$)/)?.[1])||'Graph';if(!groups.has(file))groups.set(file,[]);groups.get(file).push(node);}
  const rings=[...groups].map(([file,nodes])=>({file,section:sectionFor(file),nodes,radius:Math.max(12,12/(2*Math.sin(Math.PI/Math.max(2,nodes.length))))}));
  const sections=new Map();for(const ring of rings){if(!sections.has(ring.section))sections.set(ring.section,[]);sections.get(ring.section).push(ring);}
  const systems=[...sections].map(([name,files])=>{
    // Eight file planets per orbital shell, with enough clearance for the largest file.
    const maxRadius=Math.max(...files.map(f=>f.radius)),spacing=maxRadius*2+32;
    const shellStep=spacing/(2*Math.sin(Math.PI/8));const orbits=[];
    files.forEach((file,i)=>{const shell=Math.floor(i/8),count=Math.min(8,files.length-shell*8);const orbit=(shell+1)*shellStep;const angle=(i%8)/count*Math.PI*2;file.x=Math.cos(angle)*orbit;file.z=Math.sin(angle)*orbit;file.orbit=orbit;if(!orbits.includes(orbit))orbits.push(orbit);});
    return {name,files,orbits,radius:orbits.at(-1)+maxRadius+20};
  });
  const columns=Math.ceil(Math.sqrt(systems.length)),widths=Array(columns).fill(0),heights=Array(Math.ceil(systems.length/columns)).fill(0);
  systems.forEach((s,i)=>{widths[i%columns]=Math.max(widths[i%columns],s.radius*2+64);heights[Math.floor(i/columns)]=Math.max(heights[Math.floor(i/columns)],s.radius*2+64);});
  const offset=(sizes,i)=>sizes.slice(0,i).reduce((a,b)=>a+b,0)+sizes[i]/2-sizes.reduce((a,b)=>a+b,0)/2;
  const positions=Object.create(null);
  systems.forEach((system,i)=>{system.x=offset(widths,i%columns);system.z=offset(heights,Math.floor(i/columns));system.files.forEach(ring=>{ring.x+=system.x;ring.z+=system.z;ring.nodes.forEach((node,j)=>{const angle=j/ring.nodes.length*Math.PI*2;positions[node.id]={x:ring.x+Math.cos(angle)*ring.radius,y:3,z:ring.z+Math.sin(angle)*ring.radius,file:ring.file,section:ring.section};});});});
  return {systems:systems.map(({files,...s})=>({...s,fileCount:files.length})),rings:rings.map(({nodes,...ring})=>({...ring,count:nodes.length})),positions};
}
