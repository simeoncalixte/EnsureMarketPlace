import { layoutCallGraph } from './layout.js';
import { readFileSync } from 'node:fs';
const template = readFileSync(new URL('../templates/index.html', import.meta.url), 'utf8');
const runtime = readFileSync(new URL('./renderer.js', import.meta.url), 'utf8');

/** Generate a standalone HTML page. Omit graph to reproduce the reference exactly. */
export function createCallGraph(graph) {
  if (graph === undefined) return template;
  validateGraph(graph);
  const data = JSON.stringify(graph).replace(/</g, '\\u003c').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
  const start = template.indexOf('<script>\n(()=>{');
  return template.slice(0, start) + `<script>window.CALL_GRAPH=${data};</script>\n<script>const layoutCallGraph=${layoutCallGraph.toString()};\n${runtime}</script>\n</body>\n</html>\n`;
}

export function validateGraph(graph) {
  if (!graph || !Array.isArray(graph.nodes) || !graph.nodes.length || !Array.isArray(graph.edges)) throw new TypeError('Graph requires a nonempty nodes array and an edges array');
  const ids = new Set();
  for (const node of graph.nodes) {
    if (!node || typeof node.id !== 'string' || !node.id || ids.has(node.id)) throw new TypeError('Node IDs must be unique nonempty strings');
    ids.add(node.id);
    for (const key of ['label', 'description']) if (node[key] !== undefined && typeof node[key] !== 'string') throw new TypeError(`${key} must be a string`);
    if (node.color !== undefined && !/^#[0-9a-f]{6}$/i.test(node.color)) throw new TypeError('Colors must use #RRGGBB');
  }
  for (const edge of graph.edges) if (!edge || !ids.has(edge.source) || !ids.has(edge.target)) throw new TypeError('Every edge must reference existing nodes');
  if (graph.title !== undefined && typeof graph.title !== 'string') throw new TypeError('title must be a string');
  return graph;
}

export { analyzeCallGraph } from './analyze.js';
