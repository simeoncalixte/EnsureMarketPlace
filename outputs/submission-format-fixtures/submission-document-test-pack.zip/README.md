# Submission document test pack

All records are synthetic. Each document is under the 10 MB upload limit.

| File | What to check |
| --- | --- |
| application-multiple-pages.pdf | Text from every PDF page survives processing. |
| quote-single-page.pdf | Policy number, limits, premium and dates extract. |
| broker-cover-letter.docx | Word document paragraphs extract. |
| underwriting-notes.txt | Plain text fields extract. |
| statement-of-values.csv | Location and value columns extract. |
| scanned-application.png | Image OCR reads the application text. |
| scanned-application.jpg | JPEG image OCR reads the same application. |
| scanned-application.jpeg | The alternate JPEG extension uploads and processes. |
| multi-worksheet-schedule.xlsx | All four worksheets extract, including the final LossHistory tab. |
| multi-worksheet-schedule.xls | Legacy Excel produces the same four worksheets and values. |

## Manual checks

1. Open a draft submission's Documents section.
2. Upload one file at a time to check each extension. Use a separate draft for each file when checking its extracted fields independently.
3. Choose **Process documents** and confirm completion. Compare extracted text and fields with `manifest.json`.
4. For both Excel files, check Submission, Locations, Coverage and LossHistory. The total insured value is USD 5,000,000; the Tampa location and open claim have zero values. Formula results are stored in the files. Processing reads saved results without recalculating formulas.
5. Upload several files together and repeat with drag-and-drop. Check search, sorting, original document viewing or download, and disabled uploads during processing.

The documents contain different synthetic submissions. Uploading the entire pack together is useful for checking the upload workflow, but can produce conflicting fields. The three scan files contain identical content and may produce duplicate-content warnings when processed together.

## Automated extraction check

From `EnsuredPipelineShared`, run:

```sh
npm run build
node scripts/verifySubmissionDocumentFixtures.cjs
```

The verifier checks every expected token in `manifest.json` and forces local extraction. Image OCR may download Tesseract's English language model on its first run; no paid cloud OCR is used. Extraction checks do not replace manual review of the generated submission form.
